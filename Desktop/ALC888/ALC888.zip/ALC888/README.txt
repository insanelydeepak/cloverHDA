Codec: Realtek ALC888
Address: 0
AFG Function Id: 0x1 (unsol 1)
Vendor Id: 0x10ec0888
Subsystem Id: 0x10438445



You must change the Layout to 13, 12, 11 or 17 in the DSDT patch HDEF.

Kext Patched by Insanelydeepak 

 Determining the number Layout_ID by Ports Motherboard: 
. Layout_ID 11 = ​​3 ports supported (Pink, Green, Blue) 
. Layout_ID 12 = 5/6 ports supported (Grey, Black, Laranja, Pink, Green, Blue) 
. Layout_ID 13 = 5/6 ports supported (Grey, Black, Laranja, Pink, Green, Blue, CodecAddress: 2)

. Default is Layout_ID: 13.


Method (_DSM, 4, NotSerialized)
                {
                    Store (Package (0x0c)
                    {                        
                        "built-in", 
                        Buffer (One)
                        {
                            0x00
                        }, 
                        "layout-id", 
                        Buffer (0x04)
                        {
                            0x0D, 0x00, 0x00, 0x00 //change Your Layout_Id Here
                        }, 
                       "PinConfigurations", 
                       Buffer (0x00)
                       {
                           0x00
                       }
                    }, Local0)
                    DTGP (Arg0, Arg1, Arg2, Arg3, RefOf (Local0))
                    Return (Local0)
                }